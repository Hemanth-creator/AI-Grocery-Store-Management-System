# Ai grocery data set > 2024-09-10 6:50am
https://universe.roboflow.com/test-tkmcb/ai-grocery-data-set

Provided by a Roboflow user
License: CC BY 4.0

